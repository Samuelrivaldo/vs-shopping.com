<?php Require "connexion.php"; 

	if(isset($_POST['valider'])){
	$login = $_POST['login'];
	$mdp = $_POST['mdp'];

	$save = $pdo->prepare('INSERT INTO user(login,mdp) values (?,?)');
	$save -> execute(array($login,$mdp));
}
?>



<!DOCTYPE html>
<html>
<head>
	<title>Formulaire HTML et CSS</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
	<h1>Formulaire d'inscription</h1>
	<form action="" method="POST">
		<label for="login">login :</label>
		<input type="text" id="login" name="login"><br><br>
		<label for="mdp">mdp :</label>
		<input type="text" id="mdp" name="mdp"><br><br>
		<input type="submit" value="Valider" name="valider">
		
	</form>
</body>
</html>