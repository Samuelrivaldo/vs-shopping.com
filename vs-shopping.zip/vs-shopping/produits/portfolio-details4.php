<!DOCTYPE html>
<html lang="fr">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Détails Produits - VS-SHOPPING</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="../assets/img/vs-shoping2.png" rel="icon">
  <link href="../assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="../assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="../assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="../assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="../assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="../assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="../assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="../assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="../assets/css/style.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: Bethany - v4.7.0
  * Template URL: https://bootstrapmade.com/bethany-free-onepage-bootstrap-theme/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
  <style>
    button {
      padding: 10px;
      background-color: #009970;
      border-color: rgb(208, 208, 243);
      margin-bottom: 10px;
      border-radius: 15px;
  }
  button > a
  {
    color: rgb(255, 255, 255);
  }
   button > a:hover 
  {
    color: rgb(211, 219, 90);
  }
  </style>
</head>

<body>

  <!-- ======= Header ======= -->
  <header id="header" class="fixed-top d-flex align-items-center">
    <div class="container">
      <div class="header-container d-flex align-items-center justify-content-between">
        <div class="logo">
          <h1 class="text-light"><a href="../index.php"><span><img src="../assets/img/vs-shoping2.png" alt="Logo" 
            style="width:100px; float:left;margin-top:-10px;"></span></a></h1>
          <!-- Uncomment below if you prefer to use an image logo -->
          <!-- <a href="index.php"><img src="assets/img/logo.png" alt="" class="img-fluid"></a>-->
        </div>

        <nav id="navbar" class="navbar">
          <ul>
            <li><a class="nav-link scrollto" href="../index.php">Accueil</a></li>
            <li><a class="nav-link scrollto" href="../apropos.php">A propos</a></li>
            <li><a class="nav-link scrollto" href="../services.php">Nos Services</a></li>
           
          
            <li><a class="getstarted scrollto" href="../contact.php">Contactez-nous</a></li>
          </ul>
          <i class="bi bi-list mobile-nav-toggle"></i>
        </nav><!-- .navbar -->

      </div><!-- End Header Container -->
    </div>
  </header><!-- End Header -->

  <main id="main">

    <!-- ======= Breadcrumbs ======= -->
    <section id="breadcrumbs" class="breadcrumbs">
      <div class="container">

        <div class="d-flex justify-content-between align-items-center">
          <h2> Détails du Produit</h2>
          <ol>
            <li><a href="../index.php">Accueil</a></li>
            <li> Détails Produits</li>
          </ol>
        </div>

      </div>
    </section><!-- End Breadcrumbs -->

    <!-- ======= Portfolio Details Section ======= -->
    <section id="portfolio-details" class="portfolio-details">
      <div class="container">

        <div class="row gy-4">

          <div class="col-lg-8">
            <div class="portfolio-details-slider swiper">
              <div class="swiper-wrapper align-items-center">

                <div class="swiper-slide">
                  <img src="../assets/img/v7.jpg" alt="">
                </div>

                <div class="swiper-slide">
                  <img src="../assets/img/LA1.jpg " alt="">
                </div>

                <div class="swiper-slide">
                  <img src="../assets/img/v6.jpg" alt="">
                </div>

              </div>
              <div class="swiper-pagination"></div>
            </div>
          </div>

          <div class="col-lg-4">
            <div class="portfolio-info">
              <h3> Informations  </h3>
              <ul>
                <li><strong>Nom</strong> :   LAMBORGUHINI BLUE </li>
                <li><strong>Catégorie</strong> : LAMBORGUHINI </li>
                <li><strong>Prix</strong> : 9.000.000 € </li>
                <li><button><a href="https://wa.me/qr/7MEFLWMQEV6OG1" target="_blank"> Acheter maintenant </a></button></li>
              </ul>
            </div>
            <div class="portfolio-description">
              <h2> Description : </h2>
              <p>
                C'est une voiture exceptionnelle;
                Sa puissance : peut aller jusqu'à 355 Km/h
                de 6,5 litres. Produite qu'en 9 exemplaires.</p>
              
            </div>
          </div>

        </div>

      </div>
    </section><!-- End Portfolio Details Section -->

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <footer id="footer">

    <div class="footer-top">
      <div class="container">
        <div class="row">

          <div class="col-lg-3 col-md-6 footer-contact">
            <h3>VS-SHOPPING</h3>
            <p>
              Agla Hlazounto <br>
              Abomey Calavi, Rue 007PB <br>
              Bénin <br><br>
              <strong>Phone:</strong> +229 96 97 28 86<br>
              <strong>Email:</strong> aildevert19@gmail.com<br>
            </p>
          </div>

          <div class="col-lg-2 col-md-6 footer-links">
            <h4>Nos liens</h4>
            <ul>
              <li><i class="bx bx-chevron-right"></i> <a href="../index.php">Accueil</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="../apropos.php">A propos</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="../services.php">Nos Services</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="../contact.php">Contactez-nous</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Politique de confidentialité</a></li>
            </ul>
          </div>

         

          <div class="col-lg-4 col-md-6 footer-newsletter">
            <h4>Inscrivez-vous A notre Newsletter</h4>
            <p>Pour ne pas rater nos nouvelles publications</p>
            <form action="" method="post">
              <input type="email" name="email"><input type="submit" value="Souscrire">
            </form>
          </div>

        </div>
      </div>
    </div>

    <div class="container d-md-flex py-4">

      <div class="me-md-auto text-center text-md-start">
        <div class="copyright">
          &copy; Copyright <strong><span>VS-SHOPPING</span></strong>. Tous les droits sont réservés
        </div>
       
      </div>
      <div class="social-links text-center text-md-right pt-3 pt-md-0">
        <a href="#" target="_blank"><img src="../assets/img/facebook.png" class="icon-reseau" alt=""></a>
        <a href="https://wa.me/qr/7MEFLWMQEV6OG1" target="_blank"><img src="../assets/img/whatsapp.png" class="icon-reseau" alt=""></a>
        <a href="#" target="_blank"><img src="../assets/img/instagram.png" class="icon-reseau" alt=""></a>
      </div>
    </div>
  </footer><!-- End Footer -->


  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <script src="../assets/vendor/purecounter/purecounter.js"></script>
  <script src="../assets/vendor/aos/aos.js"></script>
  <script src="../assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="../assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="../assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="../assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="../assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="../assets/js/main.js"></script>

</body>

</html>