<ul class="x-navigation">
                    <li class="xn-logo">
                        <a href="index.html">ATLANT</a>
                        <a href="#" class="x-navigation-control"></a>                    </li>
                    <li class="xn-profile">
                        <a href="#" class="profile-mini">
                            <img src="assets/images/users/avatar.jpg" alt="John Doe"/>                        </a>
                        <div class="profile">
                            <div class="profile-image">
                                <img src="assets/images/users/avatar.jpg" alt="John Doe"/>                            </div>
                            <div class="profile-data">
                                <div class="profile-data-name">John Doe</div>
                                <div class="profile-data-title">Web Developer/Designer</div>
                            </div>
                            <div class="profile-controls">
                                <a href="pages-profile.html" class="profile-control-left"><span class="fa fa-info"></span></a>
                                <a href="pages-messages.html" class="profile-control-right"><span class="fa fa-envelope"></span></a>                            </div>
                        </div>                                                                        
                    </li>
                    <li class="xn-title">Navigation</li>
                    <li class="active">
                        <a href="index.php"><span class="fa fa-desktop"></span> <span class="xn-text">Dashboard</span></a>                    </li>                    
                    <li class="xn-openable">
                        <a href="#"><span class="fa fa-files-o"></span> <span class="xn-text">Category</span></a>
                        <ul>
                            <li><a href="category_create.php"><span class="fa fa-image"></span> Create Category</a></li>
                            <li><a href="category_view.php"><span class="fa fa-user"></span>  View Category</a></li>
                                                       
                        </ul>
                    </li>
                                        
                    <li class="xn-openable">
                        <a href="#"><span class="fa fa-files-o"></span> <span class="xn-text">Product</span></a>
                        <ul>
                            <li><a href="product_create.php"><span class="fa fa-image"></span> Create product</a></li>
                            <li><a href="product_view.php"><span class="fa fa-user"></span>  View product</a></li>
                                                       
                        </ul>
                     </li>
                      
                                        
                    <li class="xn-openable">
                        <a href="#"><span class="fa fa-files-o"></span> <span class="xn-text">Order</span></a>
                        <ul>
                            <li><a href="order.php"><span class="fa fa-image"></span>  order</a></li>
                            <li><a href="order_view.php"><span class="fa fa-user"></span>  View order</a></li>
                                                       
                        </ul>
                    </li>
                    
                    <li class="xn-openable">
                        <a href="#"><span class="fa fa-files-o"></span> <span class="xn-text">Offer</span></a>
                        <ul>
                            <li><a href="offer_create.php"><span class="fa fa-image"></span> Create offer</a></li>
                            <li><a href="offer_view.php"><span class="fa fa-user"></span>  View offer</a></li>
                                                       
                        </ul>
                    </li>
                     <li class="xn-openable">
                        <a href="#"><span class="fa fa-files-o"></span> <span class="xn-text">Review</span></a>
                        <ul>
                            <li><a href="review_create.php"><span class="fa fa-image"></span> Create review</a></li>
                            <li><a href="review_view.php"><span class="fa fa-user"></span>  View review</a></li>
                                                       
                        </ul>
                    </li>
                     <li class="">
                        <a href="profile.php"><span class="fa fa-desktop"></span> <span class="xn-text">Profile</span></a>
                        </li>
                   
                    
                      <li class="">
                        <a href="#" class="mb-control" data-box="#mb-signout"><span class="fa fa-sign-out"></span>Logout</a></li>                  
                    
                    
                                        
                                        
                    
                </ul>