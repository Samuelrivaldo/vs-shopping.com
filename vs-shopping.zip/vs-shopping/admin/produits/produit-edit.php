<?php
session_start();
require 'dbcon.php';
?>

<!doctype html>
<html lang="fr">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <title> Modifier Produit </title>
</head>
<body>
  
    <div class="container mt-5">

        <?php include('message.php'); ?>

        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4> Modifier Produit 
                            <a href="index.php" class="btn btn-danger float-end">Retour</a>
                        </h4>
                    </div>
                    <div class="card-body">

                        <?php
                        if(isset($_GET['id']))
                        {
                            $id_produit = mysqli_real_escape_string($con, $_GET['id']);
                            $query = "SELECT * FROM produits WHERE id='$id_produit' ";
                            $query_run = mysqli_query($con, $query);

                            if($query_run -> num_rows > 0)
                            {
                                $produit = mysqli_fetch_array($query_run);
                                ?>
                                <form action="code.php" method="POST">
                                    <input type="hidden" name="id_produit" value="<?= $produit['id']; ?>">

                                    <div class="mb-3">
                                        <label>Images</label>
                                        <input type="file" name="fileImg" value="<?=$produit['images'];?>" class="form-control">
                                    </div>
                                    <div class="mb-3">
                                        <label>Désignation</label>
                                        <input type="text" name="Designation" value="<?=$produit['Designation'];?>" class="form-control">
                                    </div>
                                    <div class="mb-3">
                                        <label>Catégorie</label>
                                        <input type="text" name="Categorie" value="<?=$produit['Categorie'];?>" class="form-control">
                                    </div>
                                    <div class="mb-3">
                                        <label>Prix</label>
                                        <input type="number" name="Prix" value="<?=$produit['Prix'];?>" class="form-control">
                                    </div>
                                    <div class="mb-3">
                                        <label>Description</label>
                                        <textarea type="text" name="Descr"  class="form-control"><?=$produit['Descr'];?></textarea>
                                    </div>
                                    <div class="mb-3">
                                        <button type="submit" name="update_produit" class="btn btn-primary">
                                            Mettre à jour 
                                        </button>
                                    </div>

                                </form>
                                <?php
                            }
                            else
                            {
                                echo "<h4>Aucun identifiant de ce type trouvé</h4>";
                            }
                        }
                        ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="css/bootstrap.bundle.min.js"></script>
</body>
</html>