<?php

$con = mysqli_connect("localhost","root","","vs-shoppingg");

if(!$con){
    die('Connection Failed'. mysqli_connect_error());
}

