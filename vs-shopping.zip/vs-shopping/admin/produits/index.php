<?php 
    session_start();
    require 'dbcon.php';
?>
<!doctype html>
<html lang="fr">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <title> Gestion Produits </title>
</head>
<body>
  
    <div class="container mt-4">

        <?php include('message.php'); ?>

        <div class="row" style="">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4> Details produits
                            <a href="produit-create.php" class="btn btn-primary float-end">Ajouter Produits</a>
                        </h4>
                    </div>
                    <div class="card-body">

                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>Id</th>
									<th>Images</th>
                                    <th>Désignation</th>
                                    <th>Catégorie</th>
                                    <th>Prix</th>
                                    <th>Description</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php 
                                    $query = "SELECT * FROM produits";
                                    $query_run = mysqli_query($con, $query);

                                    if(mysqli_num_rows($query_run) > 0)
                                    {
                                        foreach($query_run as $produit)
                                        {
                                            ?>
                                            <tr>
                                                <td><?= $produit['id']; ?></td>
												<td> <img src="../../<?= $produit['images']; ?>" height="50" width="50"></td>
                                                <td><?= $produit['Designation']; ?></td>
                                                <td><?= $produit['Categorie']; ?></td>
                                                <td><?= $produit['Prix']; ?></td>
                                                <td><?= $produit['Descr']; ?></td>
                                                <td style="width:45%; text-align:center;">
                                                    <a href="produit-view.php?id=<?= $produit['id']; ?>" class="btn btn-info btn-sm">Voir</a>
                                                    <a href="produit-edit.php?id=<?= $produit['id']; ?>" class="btn btn-success btn-sm">Modifier</a>
                                                    <form action="code.php" method="POST" class="d-inline">
                                                        <button type="submit" name="delete_produit" value="<?=$produit['id'];?>" class="btn btn-danger btn-sm">Supprimer</button>
                                                    </form>
                                                </td>
                                            </tr>
                                            <?php
                                        }
                                    }
                                    else
                                    {
                                        echo "<h5> Aucun Enregistrement Trouvé</h5>";
                                    }
                                ?>
                                
                            </tbody>
                        </table>

                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="css/bootstrap.bundle.min.js"></script>

</body>
</html>