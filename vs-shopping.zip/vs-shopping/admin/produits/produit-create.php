<?php  
session_start();
require 'dbcon.php';
?>

<!doctype html>
<html lang="fr">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <title>Ajout de produit</title>
</head>
<body>
  
    <div class="container mt-5">

        <?php include('message.php'); ?>

        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4>Ajouter produit 
                            <a href="index.php" class="btn btn-danger float-end">Retour</a>
                        </h4>
                    </div>
                    <div class="card-body">
                        <form action="code.php" method="POST" enctype="multipart/form-data">

                                    <div class="mb-3">
                                        <span>Redimentionnez la taille de l'image en respectant pour Largeur : 500px et Hauteur : 331px. </span>
                                        <label>Images</label>
                                        <input type="file" name="fileImg" class="form-control">
                                    </div>
                                    <div class="mb-3">
                                        <label>Désignation</label>
                                        <input type="text" name="Designation"  class="form-control">
                                    </div>
                                    <div class="mb-3">
                                        <label>Catégorie</label>
                                        <select name="Categorie" id="categorie" class="form-control">
                                <option value=""> Choisissez une catégorie </option>
                                    <?php 
        
                                        $pdo = new PDO("mysql:host=localhost;dbname=vs-shopping;charset=utf8","root","");

			                            $save = $pdo->query("SELECT * FROM categorie");

                                        foreach ($save->fetchAll() as $row)
	                                    { ?>
			                         <option value="<?php echo $row['Categories'];?>"><?php echo $row['Categories'];?></option>
                                        <?php  }?>    
                                        </select>
                                    </div>
                                    <div class="mb-3">
                                        <label>Prix</label>
                                        <input type="number" name="Prix" class="form-control">
                                    </div>
                                    <div class="mb-3">
                                        <label>Description</label>
                                        <textarea type="text" name="Descr" class="form-control"></textarea>
                                    </div>
                            <div class="mb-3">
                                <button type="submit" name="save_produit" class="btn btn-primary">Valider</button>
                            </div>

                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="css/bootstrap.bundle.min.js"></script>
</body>
</html>