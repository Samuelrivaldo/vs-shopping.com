<?php
if (isset($_FILES['fileImg'])) {

    $tmp_name = $_FILES['fileImg']['tmp_name'];

    $file_extension = strrchr($_FILES['fileImg']['type'], "/");
    $file_extension = str_replace("/", ".", $file_extension);

    $file_name = date("ymdhs") . $file_extension;
    $folder = 'images/';
    $max_size = 5000000;
    $file_size = filesize($tmp_name);

    $extension_array = array('.png', '.jpg', '.jpeg');


    if ($file_size > $max_size) {
        $error = 'Fichier trop volumineux';
    }

    if (!in_array($file_extension, $extension_array)) {
        $error = "Mauvais type de fichier";
    }

    if(!isset($error)) {
        if(move_uploaded_file($tmp_name, $folder . $file_name)) {
            echo "C'est réussi !";
        }
        else {
            echo "Ah...il semblerait que ça ne se passe pas comme prévu..";
        }
    }
    else {
        echo '<div>' . $error . '</div>';
    }
}

?>


