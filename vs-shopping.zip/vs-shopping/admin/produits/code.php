<?php
session_start();
require 'dbcon.php';

if(isset($_POST['delete_produit']))
{
    $id_produit = mysqli_real_escape_string($con, $_POST['delete_produit']);

    $query = "DELETE FROM produits WHERE id='$id_produit' ";
    $query_run = mysqli_query($con, $query);

    if($query_run)
    {
        $_SESSION['message'] = "Le produit a été supprimé avec succès";
        header("Location: index.php");
        exit(0);
    }
    else
    {
        $_SESSION['message'] = "Le produit n'a paqs été supprimé";
        header("Location: index.php");
        exit(0);
    }
}

if(isset($_POST['update_produit']))
{
    $id_produit = mysqli_real_escape_string($con, $_POST['id_produit']);
    


    $images = mysqli_real_escape_string($con, $_POST['fileImg']);
    $Designation = mysqli_real_escape_string($con, $_POST['Designation']);
    $Categorie = mysqli_real_escape_string($con, $_POST['Categorie']);
    $Prix = mysqli_real_escape_string($con, $_POST['Prix']);
    $Descr = mysqli_real_escape_string($con, $_POST['Descr']);

    $query = "UPDATE produits SET images='$images', Designation='$Designation', Categorie='$Categorie', Prix='$Prix',Descr='$Descr' WHERE id='$id_produit' ";
    $query_run = mysqli_query($con, $query);

    if($query_run)
    {
        $_SESSION['message'] = "Le produit a été modifié avec succès !";
        header("Location: index.php");
        exit(0);
    }
    else
    {
        $_SESSION['message'] = "Le produit n'a pas été modifié ";
        header("Location: index.php");
        exit(0);
    }

}


if(isset($_POST['save_produit']))
{

if (isset($_FILES['fileImg'])) {

    $tmp_name = $_FILES['fileImg']['tmp_name'];

    $file_extension = strrchr($_FILES['fileImg']['type'], "/");
    $file_extension = str_replace("/", ".", $file_extension);

    $file_name = date("ymdhs") . $file_extension;
    $folder = 'assets/img/';
    $max_size = 5000000;
    $file_size = filesize($tmp_name);

    $extension_array = array('.png', '.jpg', '.jpeg');


    if ($file_size > $max_size) {
        $error = 'Fichier trop volumineux';
    }

    if (!in_array($file_extension, $extension_array)) {
        $error = "Mauvais type de fichier";
    }

    if(!isset($error)) {
        if(move_uploaded_file($tmp_name, $folder . $file_name)) {
            echo "C'est réussi !";
        }
        else {
            echo "Ah...il semblerait que ça ne se passe pas comme prévu..";
        }
    }
    else {
        echo '<div>' . $error . '</div>';
    }
}

    
    
    

    $Designation = mysqli_real_escape_string($con, $_POST['Designation']);
    $Categorie = mysqli_real_escape_string($con, $_POST['Categorie']);
    $Prix = mysqli_real_escape_string($con, $_POST['Prix']);
    $Descr = mysqli_real_escape_string($con, $_POST['Descr']);

    $query = "INSERT INTO produits (images,Designation,Categorie,Prix,Descr) VALUES (' $folder$file_name')','$Designation','$Categorie','$Prix','$Descr')";

    $query_run = mysqli_query($con, $query);
    if($query_run)
    {
        $_SESSION['message'] = "Le produit a été ajouté avec succès !";
        header("Location: produit-create.php");
        exit(0);
    }
    else
    {
        $_SESSION['message'] = "Le produit a été ajouté avec succès !";
        header("Location: produit-create.php");
        exit(0);
    }
}

?>
