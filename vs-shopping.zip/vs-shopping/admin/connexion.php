
<?php
// Connexion à la base de données en utilisant PDO
try {
    $pdo = new PDO("mysql:host=localhost;dbname=vs-shoppingg", "root", "");
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("La connexion à la base de données a échoué : " . $e->getMessage());
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'];
    $mot_de_passe = $_POST['mot_de_passe'];

    // Exemple de requête SQL pour vérifier l'authentification (à personnaliser)
    $stmt = $pdo->prepare("SELECT id_user, mot_de_passe FROM user WHERE email = ?");
    $stmt->execute([$email]);
    $row = $stmt->fetch();

    if ($row && password_verify($mot_de_passe, $row['mot_de_passe'])) {
        // Authentification réussie, créer une session
        session_start();
        $_SESSION['id_user'] = $row['id_user'];

        // Rediriger l'utilisateur vers son tableau de bord ou une autre page sécurisée
        header('Location: admin/index.html');
        exit;
    } else {
        // Authentification échouée, afficher un message d'erreur
        $erreur = "Adresse email ou mot de passe incorrect";
    }
}

?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Connexion</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="icon" href="images/logo.jpg" type="image/x-icon">
</head>
<body>
    <div class="form-container">
        <h2>Connexion</h2>
        <form method="POST" action=""> 
            <input type="email" name="email" placeholder="Email" required>
            <input type="password" name="mot_de_passe" placeholder="Mot de passe" required>
            <button type="submit">Se connecter</button>
        </form>
        <p>Pas encore de compte ? <a href="index.php">S'inscrire</a></p> 
    </div>
</body>
</html>
