<!DOCTYPE html>
<html lang="fr">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>SERVICES</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/vs-shoping2.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: Bethany - v4.7.0
  * Template URL: https://bootstrapmade.com/bethany-free-onepage-bootstrap-theme/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body>

  <!-- ======= Header ======= -->
  <header id="header" class="fixed-top d-flex align-items-center">
    <div class="container">
      <div class="header-container d-flex align-items-center justify-content-between">
        <div class="logo">
          <h1 class="text-light"><a href="index.php"><span><img src="assets/img/vs-shoping2.png" alt="Logo" 
            style="width:100px; float:left;margin-top:-10px;"></span></a></h1>
          <!-- Uncomment below if you prefer to use an image logo -->
          <!-- <a href="index.php"><img src="assets/img/logo.png" alt="" class="img-fluid"></a>-->
        </div>

        <nav id="navbar" class="navbar">
          <ul>
            <li><a class="nav-link scrollto " href="index.php">Accueil</a></li>
            <li><a class="nav-link scrollto" href="apropos.php">A propos</a></li>
            <li><a class="nav-link scrollto active" href="services.php">Nos Services</a></li>
           
          
            <li><a class="getstarted scrollto" href="contact.php">Contactez-nous</a></li>
          </ul>
          <i class="bi bi-list mobile-nav-toggle"></i>
        </nav><!-- .navbar -->

      </div><!-- End Header Container -->
    </div>
  </header><!-- End Header -->
  <br><br><br><br>
  <!-- ======= Services Section ======= -->
  
 <!-- ======= Portfolio Section ======= -->
 <section id="portfolio" class="portfolio">
    <div class="container">

      <div class="section-title" data-aos="fade-left">
        <h2>SERVICES</h2>
        <marquee behavior="" direction=""><p>Faîtes vos achats de voiture en ligne en toute sécurité</p></marquee>
      </div>

      <div class="row" data-aos="fade-up" data-aos-delay="100">
        <div class="col-lg-12 d-flex justify-content-center">
          <ul id="portfolio-flters">
            <li data-filter="*" class="filter-active">Tous</li>
            <li data-filter=".filter-app">BUGATTI & MERCEDES </li>
            <li data-filter=".filter-card">ROLS-ROYCE</li>
            <li data-filter=".filter-web">LAMBORGUHINI</li>
            
          </ul>
        </div>
      </div>

      <div class="row portfolio-container" data-aos="fade-up" data-aos-delay="200">

        <div class="col-lg-4 col-md-6 portfolio-item filter-app">
          <div class="portfolio-wrap">
            <img src="assets/img/v1.jpg" class="img-fluid" alt="">
            <div class="portfolio-info">
              <h4>Bugatti 1</h4>
              <p>bugatti</p>
              <div class="portfolio-links">
                <a href="assets/img/v1.jpg" data-gallery="portfolioGallery" class="portfolio-lightbox" title="Bugatti 1"><i class="bx bx-plus"></i></a>
                <a href="produits/portfolio-details.php" title="Plus de Détails"><i class="bx bx-link"></i></a>
              </div>
            </div>
          </div>
        </div>

        <div class="col-lg-4 col-md-6 portfolio-item filter-web">
          <div class="portfolio-wrap">
            <img src="assets/img/LA1.jpg" class="img-fluid" alt="">
            <div class="portfolio-info">
              <h4>Lamborguhini 1</h4>
              <p>Lamborguhini</p>
              <div class="portfolio-links">
                <a href="assets/img/LA1.jpg" data-gallery="portfolioGallery" class="portfolio-lightbox" title="Lamborguini 1 "><i class="bx bx-plus"></i></a>
                <a href="produits/portfolio-details2.php" title="Plus de Détails"><i class="bx bx-link"></i></a>
              </div>
            </div>
          </div>
        </div>

        <div class="col-lg-4 col-md-6 portfolio-item filter-app">
          <div class="portfolio-wrap">
            <img src="assets/img/v5.jpg" class="img-fluid" alt="">
            <div class="portfolio-info">
              <h4>Bugatti 2</h4>
              <p>bugatti</p>
              <div class="portfolio-links">
                <a href="assets/img/v5.jpg" data-gallery="portfolioGallery" class="portfolio-lightbox" title="Bugatti 2"><i class="bx bx-plus"></i></a>
                <a href="produits/portfolio-details1.php" title="Plus de Détails"><i class="bx bx-link"></i></a>
              </div>
            </div>
          </div>
        </div>

        <div class="col-lg-4 col-md-6 portfolio-item filter-card">
          <div class="portfolio-wrap">
            <img src="assets/img/v3.jpg" class="img-fluid" alt="">
            <div class="portfolio-info">
              <h4>Rols-Royce 1</h4>
              <p>ROLS-ROYCE</p>
              <div class="portfolio-links">
                <a href="assets/img/v3.jpg" data-gallery="portfolioGallery" class="portfolio-lightbox" title="Rols-Royce 1"><i class="bx bx-plus"></i></a>
                <a href="produits/portfolio-details5.php" title="Plus de Détails"><i class="bx bx-link"></i></a>
              </div>
            </div>
          </div>
        </div>

        <div class="col-lg-4 col-md-6 portfolio-item filter-web">
          <div class="portfolio-wrap">
            <img src="assets/img/v6.jpg" class="img-fluid" alt="">
            <div class="portfolio-info">
              <h4>Lamborguhini 2</h4>
              <p>Lamborguhini</p>
              <div class="portfolio-links">
                <a href="assets/img/v6.jpg" data-gallery="portfolioGallery" class="portfolio-lightbox" title="Lamborguini 2"><i class="bx bx-plus"></i></a>
                <a href="produits/portfolio-details3.php" title="Plus de Détails"><i class="bx bx-link"></i></a>
              </div>
            </div>
          </div>
        </div>

        <div class="col-lg-4 col-md-6 portfolio-item filter-app">
          <div class="portfolio-wrap">
            <img src="assets/img/MER1.jpg" class="img-fluid" alt="">
            <div class="portfolio-info">
              <h4>Mercedes 1</h4>
              <p>mercedes</p>
              <div class="portfolio-links">
                <a href="assets/img/MER1.jpg" data-gallery="portfolioGallery" class="portfolio-lightbox" title="Mercedes 1"><i class="bx bx-plus"></i></a>
                <a href="produits/portfolio-details8.php" title="Plus de Détails"><i class="bx bx-link"></i></a>
              </div>
            </div>
          </div>
        </div>

        <div class="col-lg-4 col-md-6 portfolio-item filter-card">
          <div class="portfolio-wrap">
            <img src="assets/img/v2.jpg" class="img-fluid" alt="">
            <div class="portfolio-info">
              <h4>Rols-Royce 2</h4>
              <p>Rols-Royce</p>
              <div class="portfolio-links">
                <a href="assets/img/v2.jpg" data-gallery="portfolioGallery" class="portfolio-lightbox" title="Rols-Royce 2"><i class="bx bx-plus"></i></a>
                <a href="produits/portfolio-details6.php" title="Plus de Détails"><i class="bx bx-link"></i></a>
              </div>
            </div>
          </div>
        </div>

        <div class="col-lg-4 col-md-6 portfolio-item filter-card">
          <div class="portfolio-wrap">
            <img src="assets/img/ROL1.jpg" class="img-fluid" alt="">
            <div class="portfolio-info">
              <h4>Rols-Royce 3</h4>
              <p>Rols-Royce</p>
              <div class="portfolio-links">
                <a href="assets/img/ROL1.jpg" data-gallery="portfolioGallery" class="portfolio-lightbox" title="Rols-Royce 3"><i class="bx bx-plus"></i></a>
                <a href="produits/portfolio-details7.php" title="Plus de Détails"><i class="bx bx-link"></i></a>
              </div>
            </div>
          </div>
        </div>

        <div class="col-lg-4 col-md-6 portfolio-item filter-web">
          <div class="portfolio-wrap">
            <img src="assets/img/v7.jpg" class="img-fluid" alt="">
            <div class="portfolio-info">
              <h4>Lamborguhini 3</h4>
              <p>Lamborguhini</p>
              <div class="portfolio-links">
                <a href="assets/img/v7.jpg" data-gallery="portfolioGallery" class="portfolio-lightbox" title="Lamborguini 3"><i class="bx bx-plus"></i></a>
                <a href="produits/portfolio-details4.php" title="Plus de Détails"><i class="bx bx-link"></i></a>
              </div>
            </div>
          </div>
        </div>

      </div>

    </div>
  </section><!-- End Portfolio Section -->
  <!-- ======= Footer ======= -->
  <footer id="footer">

    <div class="footer-top">
      <div class="container">
        <div class="row">

          <div class="col-lg-3 col-md-6 footer-contact">
            <h3>VS-SHOPPING</h3>
            <p>
              Agla Hlazounto <br>
              Abomey Calavi, Rue 007PB <br>
              Bénin <br><br>
              <strong>Phone:</strong> +229 96 97 28 86<br>
              <strong>Email:</strong> aildevert19@gmail.com<br>
            </p>
          </div>

          <div class="col-lg-2 col-md-6 footer-links">
            <h4>Nos liens</h4>
            <ul>
              <li><i class="bx bx-chevron-right"></i> <a href="index.php">Accueil</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="apropos.php">A propos</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="services.php">Nos Services</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="contact.php">Contactez-nous</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Politique de confidentialité</a></li>
            </ul>
          </div>

         

          <div class="col-lg-4 col-md-6 footer-newsletter">
            <h4>Inscrivez-vous A notre Newsletter</h4>
            <p>Pour ne pas rater nos nouvelles publications</p>
            <form action="" method="post">
              <input type="email" name="email"><input type="submit" value="Souscrire">
            </form>
          </div>

        </div>
      </div>
    </div>

    <div class="container d-md-flex py-4">

      <div class="me-md-auto text-center text-md-start">
        <div class="copyright">
          &copy; Copyright <strong><span>VS-SHOPPING</span></strong>. Tous les droits sont réservés
        </div>
       
      </div>
      <div class="social-links text-center text-md-right pt-3 pt-md-0">
        <a href="#" target="_blank"><img src="assets/img/facebook.png" class="icon-reseau" alt=""></a>
        <a href="https://wa.me/qr/7MEFLWMQEV6OG1" target="_blank"><img src="assets/img/whatsapp.png" class="icon-reseau" alt=""></a>
        <a href="#" target="_blank"><img src="assets/img/instagram.png" class="icon-reseau" alt=""></a>
      </div>
    </div>
  </footer><!-- End Footer -->


  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/purecounter/purecounter.js"></script>
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>

</body>

</html>